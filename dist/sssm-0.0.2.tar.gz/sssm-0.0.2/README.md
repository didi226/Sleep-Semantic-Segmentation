# Sleep Semantic Segmentation

## Description

- detect all sleep events
- Sleep staging

## Installation

You can either git clone this whole repo by:

```
cd Sleep Semantic Segmentation/dist
pip install wrap_sssm-0.0.1-py3-none-any.whl
```

## Usage

Sleep Semantic Segmentation

```python

```

## Cite 

The related article has not yet been published.