"""
detect
- Author: Xiaoyu Bao
- GitHub:
- License:
"""
import mne
import logging
import numpy as np
import pandas as pd
from scipy import signal
from mne.filter import filter_data
from collections import OrderedDict
from scipy.interpolate import interp1d
from scipy.fftpack import next_fast_len
from sklearn.ensemble import IsolationForest
from yasa.detection import _DetectionResults,_check_data_hypno
import seaborn as sns
from matplotlib.colors import Normalize
from matplotlib.cm import get_cmap
import matplotlib.pyplot as plt
import ipywidgets as ipy
from wrap_sssm.io import set_log_level
from sssm import ssm
logger = logging.getLogger("sssm")
##包含的函数
__all__ = []
###目前不考虑分期的情况
def  sleep_event_detect(
    data,
    sf=None,
    wave_name= ['Spindle', 'Background', 'Arousal','K-complex', 'Slow wave', 'Vertex Sharp', 'Sawtooth'],

    device='cuda',
    model_name='model.pt',
    model_path=None,
    step = 50,
    event_threshold = {
                'Spindle': 0.95,
                'Background': 0.9,
                'Arousal': 0.9,
                'K-complex': 0.6,
                'Slow wave': 0.6,
                'Vertex Sharp': 0.6,
                'Sawtooth': 0.6},
overall_threshold=0.5,
    verbose=False,
):
    set_log_level(verbose)

    thresh_standard = {'Spindle': 0.95,'Background': 0.9,'Arousal': 0.9,'K-complex': 0.6,
    'Slow wave': 0.6,'Vertex Sharp': 0.6,'Sawtooth': 0.6}
    for i_thresh in thresh_standard.keys():
        if i_thresh not in event_threshold.keys():
            event_threshold[i_thresh] = thresh_standard[i_thresh]
    model = ssm.SSM(device=device, model_name=model_name, model_path=model_path)
    return SleepEventDetect(model, wave_name, data, sf, event_threshold,step,overall_threshold)
#_DetectionResults
class SleepEventDetect():
    def __init__(self, model, wave_name, data, sf, thresh,step,overall_threshold):
        self._model = model

        self._wave_name = wave_name
        self._data = data
        self._sf = sf
        self._event_threshold = thresh
        self._step = step
        ret = self._model.predict(data, step=step)
        self.event_df = self._model.to_pandas(overall_threshold=overall_threshold, event_threshold=self._event_threshold)
        self._times = np.arange(  self._data .shape[-1]) / self._sf

    def summary(self):
        filtered_df = self.event_df[self.event_df['label'].isin(self._wave_name)]
        return filtered_df
    def _get_event_df(self, wave_names):
        filtered_df = self.event_df[self.event_df['label'].isin(wave_names)]
        return filtered_df


    def plot_average(self, event_type=None,  figsize=(6, 4.5),**kwargs):
        if event_type is None:
            event_type = self._wave_name
        ###图位置参数的设置与波的特征有关（这部分后面再处理）
        if set(event_type).issubset(set( self._wave_name)):
            event_data = []
            for i_event in event_type:
                i_event_df = self.event_df[self.event_df['label'] == i_event]
                segments = []
                for index, row in i_event_df.iterrows():
                    center = (row['Start']+row['End'])/2
                    segment = self._data[:,int(center-1.5*self._sf): int(center+1.5*self._sf)]
                    segments.append(segment)
                segment_ave = np.mean(np.array(segments),axis=0)
                event_data.append(segment_ave)
            figsize = (len(event_type) * figsize[0], figsize[1])
            fig, axs = plt.subplots(1, len(event_type), figsize=figsize)
            for index, i_event in enumerate(event_type):
                times = np.arange(event_data[index].shape[-1]) / self._sf
                data = np.squeeze(event_data[index])
                axs[index].plot(times, data, **kwargs)
                axs[index].set_title(f"Average {i_event}")
                axs[index].set_xlabel("Time (sec)")
                axs[index].set_ylabel("Amplitude (uV)")
        else:
            raise ValueError(f'event_type {event_type} is not corrected')
        return axs
    def _get_mask(self):
        mask_dict = {}
        for event in self._wave_name:
            i_event_df = self._get_event_df([event])
            mask_dict[event] =[]
            for index, row in i_event_df.iterrows():
                mask_dict[event].append(range(row['Start'], row['End']))
        return mask_dict

    def plot_detection(self, event_type=None,  figsize=(12, 4), cmap='Spectral'):
        if event_type is None:
            event_type = self._wave_name
        if not set(event_type).issubset(set(self._wave_name)):
            raise ValueError(f'event_type {event_type} is not correct')
        cmap = get_cmap(cmap)
        win_size = 10
        n_epochs = int((self._data.shape[-1] / self._sf) / win_size)
        data = np.squeeze(self._data)
        norm = Normalize(vmin=0, vmax=len(event_type) - 1)
        fig, ax = plt.subplots(figsize = figsize)
        initial_line, = ax.plot(self._times, data, "k", lw=1, label='Original Data')
        mask = self._get_mask()
        # 绘制每个事件类型的数据，并存储线条对象到 self.lines
        lines = []
        for index, i_event in enumerate(event_type):
            for i_list in mask[i_event]:
                line, = ax.plot(self._times[i_list], data[i_list], color=cmap(norm(index)), label=f'{i_event}')
                lines.append(line)
        plt.xlabel("Time (seconds)")
        plt.ylabel("Amplitude (uV)")
        plt.legend()
        fig.canvas.header_visible = False
        fig.tight_layout()
        layout = ipy.Layout(width="50%", justify_content="center", align_items="center")

        sl_ep = ipy.IntSlider(
            min=0,
            max=n_epochs,
            step=1,
            value=0,
            layout=layout,
            description="Epoch:",
        )

        sl_amp = ipy.IntSlider(
            min=25,
            max=500,
            step=25,
            value=150,
            layout=layout,
            orientation="horizontal",
            description="Amplitude:",
        )


        dd_win = ipy.Dropdown(
            options=[1, 5, 10, 30, 60],
            value=win_size,
            description="Window size:",
        )

        dd_check = ipy.Checkbox(
            value=False,
            description="Filtered",
        )

        def update(epoch, amplitude, win_size):
            """Update plot."""
            n_epochs = int((self._data.shape[-1] / self._sf) / win_size)
            sl_ep.max = n_epochs
            xlim = [epoch * win_size, (epoch + 1) * win_size]
            xrng = np.arange(xlim[0] * self._sf, (xlim[1] * self._sf), dtype=int)

            # 更新初始绘制的数据线条
            try:
                initial_line.set_data(self._times[xrng], data[xrng])
            except IndexError:
                pass
            for idx, i_event in enumerate(event_type):
                try:
                    lines[idx].set_data(self._times[mask[i_event]][xrng], data[mask[i_event]][xrng])
                except IndexError:
                    pass
            ax.set_xlim(xlim)
            ax.set_ylim([-amplitude, amplitude])
            ax.legend()
        interact_obj = ipy.interact(update, epoch=sl_ep, amplitude=sl_amp, win_size=dd_win)
        return interact_obj

